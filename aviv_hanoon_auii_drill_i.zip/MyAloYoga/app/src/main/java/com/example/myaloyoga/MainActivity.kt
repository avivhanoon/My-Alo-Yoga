package com.example.myaloyoga

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

data class CartItem(val name: String, val size: String, val price: Double, val imageResId: Int)

class MainActivity : AppCompatActivity() {

    private lateinit var newDropShopNowTextView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var checkoutButton: Button
    private lateinit var totalPriceTextView: TextView

    // Changes to support multiple cart items
    private val cartItems = mutableListOf<CartItem>()
    private var checkoutDialog: AlertDialog? = null

    private lateinit var textArray: Array<String>
    private var currentIndex = 0

    private val textChangeRunnable = object : Runnable {
        override fun run() {
            val fadeOut = android.view.animation.AnimationUtils.loadAnimation(this@MainActivity, R.anim.fade_out)
            newDropShopNowTextView.startAnimation(fadeOut)

            fadeOut.setAnimationListener(object : android.view.animation.Animation.AnimationListener {
                override fun onAnimationStart(animation: android.view.animation.Animation) {}

                override fun onAnimationEnd(animation: android.view.animation.Animation) {
                    currentIndex = (currentIndex + 1) % textArray.size
                    newDropShopNowTextView.text = textArray[currentIndex]
                    val fadeIn = android.view.animation.AnimationUtils.loadAnimation(this@MainActivity, R.anim.fade_in)
                    newDropShopNowTextView.startAnimation(fadeIn)
                }

                override fun onAnimationRepeat(animation: android.view.animation.Animation) {}
            })

            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.my_main_layout)

        checkoutButton = findViewById(R.id.checkoutbtn)
        newDropShopNowTextView = findViewById(R.id.newdropstring)

        // Initialize the textArray here to avoid early access issues
        textArray = arrayOf(getString(R.string.new_drop_shop_now), getString(R.string.explore_our_latest_collection))

        checkoutButton.setOnLongClickListener {
            val rotateAnimation = android.view.animation.AnimationUtils.loadAnimation(this, R.anim.rotate)
            checkoutButton.startAnimation(rotateAnimation)
            true
        }

        val sizes = arrayOf(getString(R.string.xs), getString(R.string.s),
            getString(R.string.m), getString(R.string.l), getString(R.string.xl))
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sizes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        val sizeSpinner2: Spinner = findViewById(R.id.sizeSpinner_for_black_and_white_bra)
        val sizeSpinner1: Spinner = findViewById(R.id.sizeSpinner_for_black_and_white_leggings)
        val sizeSpinner3: Spinner = findViewById(R.id.sizeSpinner_for_magnified_bra)
        val sizeSpinner4: Spinner = findViewById(R.id.sizeSpinner_for_magnified_leggings)

        sizeSpinner1.adapter = adapter
        sizeSpinner2.adapter = adapter
        sizeSpinner3.adapter = adapter
        sizeSpinner4.adapter = adapter

        sizeSpinner1.setSelection(0)
        sizeSpinner2.setSelection(0)
        sizeSpinner3.setSelection(0)
        sizeSpinner4.setSelection(0)

        val imageButton1 = findViewById<ImageButton>(R.id.black_and_white_top)
        val imageButton2 = findViewById<ImageButton>(R.id.leggings_black_and_white)
        val imageButton3 = findViewById<ImageButton>(R.id.white_top)
        val imageButton4 = findViewById<ImageButton>(R.id.white_leggings)

        imageButton1.setOnClickListener { showShoppingCartDialog(sizeSpinner1,
            getString(R.string.black_and_white_bra), 79.99, R.drawable.topblackandwhite) }
        imageButton2.setOnClickListener { showShoppingCartDialog(sizeSpinner2, getString(R.string.black_and_white_leggings), 79.99, R.drawable.leggingsblackandwhite) }
        imageButton3.setOnClickListener { showShoppingCartDialog(sizeSpinner3, getString(R.string.magnified_plaid_bra), 79.99, R.drawable.whitetop) }
        imageButton4.setOnClickListener { showShoppingCartDialog(sizeSpinner4, getString(R.string.magnified_plaid_leggings), 79.99, R.drawable.whiteleggings) }

        handler.postDelayed(textChangeRunnable, 3000)

        checkoutButton.setOnClickListener {
            showCheckoutDialog()
        }
    }

    private fun showShoppingCartDialog(sizeSpinner: Spinner, itemName: String, itemPrice: Double, imageResId: Int) {
        val selectedSize = sizeSpinner.selectedItem.toString()
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_shopping_cart, null)
        val dialogMessage = dialogView.findViewById<TextView>(R.id.dialogMessage)
        dialogMessage.text = getString(
            R.string.are_you_sure_you_want_to_add_size_to_the_shopping_cart,
            itemName,
            selectedSize
        )

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        dialogView.findViewById<Button>(R.id.btnCancel).setOnClickListener {
            dialog.dismiss()
        }

        dialogView.findViewById<Button>(R.id.btnConfirm).setOnClickListener {
            // Key change: Allow multiple items by not checking for existing items
            val newItem = CartItem(itemName, selectedSize, itemPrice, imageResId)
            cartItems.add(newItem)

            Toast.makeText(this,
                getString(R.string.added_size_to_the_shopping_cart, itemName, selectedSize), Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showCheckoutDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_checkout, null)
        val cartItemsLayout = dialogView.findViewById<LinearLayout>(R.id.cartItemsLayout)
        totalPriceTextView = dialogView.findViewById(R.id.totalPrice)

        // Clear previous views
        cartItemsLayout.removeAllViews()

        // Add each cart item to the dialog
        cartItems.forEach { cartItem ->
            val itemView = LayoutInflater.from(this).inflate(R.layout.cart_item, cartItemsLayout, false)
            val itemImageView = itemView.findViewById<ImageView>(R.id.itemImage)
            val itemNameView = itemView.findViewById<TextView>(R.id.itemName)
            val itemSizeView = itemView.findViewById<TextView>(R.id.itemSize)
            val itemPriceView = itemView.findViewById<TextView>(R.id.itemPrice)
            val removeItemButton = itemView.findViewById<ImageButton>(R.id.removeItemButton)

            itemImageView.setImageResource(cartItem.imageResId)
            itemNameView.text = cartItem.name
            itemSizeView.text = cartItem.size
            itemPriceView.text = "$${cartItem.price}"

            removeItemButton.setOnClickListener {
                // Remove the specific item from the cart
                cartItems.remove(cartItem)
                cartItemsLayout.removeView(itemView)
                updateTotalPrice()
            }

            cartItemsLayout.addView(itemView)
        }

        // Update total price
        updateTotalPrice()

        // Add a checkout button to the dialog
        val checkoutButton = Button(this).apply {
            text = context.getString(R.string.checkout)
            setOnClickListener {
                // Display success message
                Toast.makeText(this@MainActivity, "Purchase successful!", Toast.LENGTH_SHORT).show()
                // Clear cart items
                cartItems.clear()
                // Dismiss the dialog
                checkoutDialog?.dismiss()
            }
        }

        cartItemsLayout.addView(checkoutButton)

        // Create a new checkout dialog every time to ensure it displays the updated list of items
        checkoutDialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .create()

        checkoutDialog?.show()
    }

    private fun updateTotalPrice() {
        val totalPrice = cartItems.sumOf { it.price }
        totalPriceTextView.text =
            getString(R.string.total, "%.2f".format(totalPrice))
    }
}
